import { h } from 'preact';
import { useState } from 'preact/hooks';

const { STab, SFloating, SRadarChart, SExpand, SVariableImage } =
  window.sComponents;
const { get, useMessageData, appendItemInput, renderComponent } = window.sUtils;

function getProperties(chara) {
  const p = chara.property ?? {
    str: 0,
    dex: 0,
    con: 0,
    int: 0,
    wis: 0,
    cha: 0,
  };
  return [
    { id: 'str', name: '力量', value: p.str ?? 0 },
    { id: 'dex', name: '敏捷', value: p.dex ?? 0 },
    { id: 'con', name: '体质', value: p.con ?? 0 },
    { id: 'int', name: '智力', value: p.int ?? 0 },
    { id: 'wis', name: '感知', value: p.wis ?? 0 },
    { id: 'cha', name: '魅力', value: p.cha ?? 0 },
  ];
}

// ============================================================
// 个人状态 — 身份卡
// ============================================================
function ProfileCard({ chara }) {
  const staColor = getStatusColor(chara.status);
  return h(
    'div',
    {
      className: 'profile-card',
      style: { '--avatar-status-color': staColor },
    },
    [
      h(
        'div',
        { className: 'profile-avatar' },
        h(SVariableImage, {
          className: 'profile-avatar',
          name: `avatar-${chara.name}`,
          defaultComponent: () => {
            h(
              'span',
              { className: 'profile-avatar-fallback' },
              chara.name?.[0] || '?',
            );
          },
        }),
      ),
      h(
        'div',
        { className: 'profile-info' },
        h('div', { className: 'profile-name' }, chara.name),
        h('div', { className: 'profile-desc' }, chara.desc),
      ),
    ],
  );
}

// ============================================================
// 个人状态 — 属性卡片（六维 + 雷达图）
// ============================================================
function PropertyCard({ chara }) {
  const properties = getProperties(chara);
  const max = properties.reduce(
    (max, current) => Math.max(Math.abs(current.value) + 1, max),
    1,
  );
  const min = properties.reduce(
    (min, current) => Math.min(Math.abs(current.value), min),
    max,
  );
  return h(
    'div',
    { className: 'property-card' },
    h(
      'div',
      { className: 'property-items' },
      properties.map((p) => {
        return h(
          'div',
          { className: 'property-item', key: p.id },
          h('div', { className: 'property-label' }, p.name),
          h(
            'div',
            {
              className: 'property-progress',
              style: {
                '--percentage': Math.abs((100 * p.value) / max).toFixed(2),
              },
            },
            h('div', {
              className: `property-progress-bar${p.value < 0 ? ' reverse' : ''}`,
            }),
          ),
          h('div', { className: 'property-value' }, p.value),
        );
      }),
    ),
    h(
      'div',
      { className: 'property-radar' },
      h(SRadarChart, { items: properties, max: max, min: min * 0.9 }),
    ),
  );
}

// ============================================================
// Tab: 🩺 个人状态
// ============================================================
function PropertyTabContent({ user }) {
  return [h(ProfileCard, { chara: user }), h(PropertyCard, { chara: user })];
}

// ============================================================
// Tab: 👥 角色列表 — 角色卡片
// ============================================================

function getRelationColor(status) {
  return (
    {
      友好: 'var(--green)',
      中立: 'var(--blue)',
      敌对: 'var(--red)',
    }[status] ?? 'var(--text2)'
  );
}

function getStatusColor(status) {
  return (
    {
      健康: '#16a34a',
      危险: '#ea580c',
      死亡: '#dc2626',
    }[status] ?? 'var(--text3)'
  );
}

function CharaCard({ chara }) {
  const relColor = getRelationColor(chara.relation);
  const staColor = getStatusColor(chara.status);

  return h(SExpand, {
    className: 'chara-card',
    header: () => [
      h('span', { className: 's-card-title' }, chara.name),
      chara.relation
        ? h(
            'span',
            {
              className: 'chara-relation',
              style: { color: relColor, borderColor: relColor },
            },
            chara.relation,
          )
        : null,
      h(
        'span',
        {
          className: 'chara-status-tag',
          style: { color: staColor, borderColor: staColor },
        },
        chara.status ?? '未知',
      ),
      h(
        'button',
        {
          className: 's-card-add',
          onClick: (e) => {
            e.stopPropagation();
            appendItemInput(chara);
          },
        },
        '✚',
      ),
    ],
    children: () => [
      h(ProfileCard, { chara }),
      h('div', { className: 'build-desc' }, chara.statusDesc),
      h(PropertyCard, { chara }),
    ],
  });
}

function CharasTabContent({ charas }) {
  const entries = Object.entries(charas || {});
  if (entries.length === 0) {
    return h(
      'div',
      { className: 'chara-empty' },
      h('div', { className: 'chara-empty-icon' }, '👥'),
      h('div', { className: 'chara-empty-text' }, '暂无角色信息'),
    );
  }
  return h(
    'div',
    { className: 'charas-list' },
    entries.map(([name, data]) => h(CharaCard, { chara: data, key: name })),
  );
}

// ============================================================
// Tab: 🏗️ 建筑总览
// ============================================================

function getBuildTypeStyle(type) {
  const t = (type || '').trim();
  const rules = [
    { match: /居住|房屋|宿舍|帐篷/, icon: '🏠', color: 'var(--green)' },
    { match: /生产|工坊|制造|熔炉|厨房/, icon: '🔧', color: 'var(--orange)' },
    { match: /仓储|仓库|地窖/, icon: '📦', color: '#ca8a04' },
    { match: /防御|哨塔|围墙|陷阱|堡垒/, icon: '🛡️', color: 'var(--red)' },
    { match: /农业|菜园|种植|养殖|农场/, icon: '🌾', color: '#8b5cf6' },
    { match: /医疗|诊所|药房/, icon: '🏥', color: 'var(--blue)' },
    { match: /研究|实验室|图书馆/, icon: '🔬', color: '#a855f7' },
    { match: /探索|通讯|侦察|无线电/, icon: '📡', color: '#06b6d4' },
  ];
  for (const r of rules) {
    if (r.match.test(t)) return { icon: r.icon, color: r.color };
  }
  return { icon: '🏗️', color: 'var(--text3)' };
}

function getBuildStatusStyle(status) {
  const s = (status || '').trim();
  const rules = [
    {
      match: /运作中|正常|健康/,
      color: 'var(--green)',
      bg: 'rgba(22,163,74,.12)',
    },
    {
      match: /建设中|建造中|施工/,
      color: '#ca8a04',
      bg: 'rgba(202,138,4,.12)',
    },
    { match: /损坏|破损|坍塌/, color: 'var(--red)', bg: 'rgba(220,38,38,.12)' },
    {
      match: /闲置|空闲|无人|休眠/,
      color: 'var(--text3)',
      bg: 'rgba(0,0,0,.04)',
    },
  ];
  for (const r of rules) {
    if (r.match.test(s)) return { color: r.color, bg: r.bg };
  }
  return { color: 'var(--text3)', bg: 'rgba(0,0,0,.04)' };
}

function BuildingCard({ data }) {
  const typeSty = getBuildTypeStyle(data.type);
  const statSty = getBuildStatusStyle(data.status);
  const lv = data.level ? `Lv.${data.level}` : '';

  return h(SExpand, {
    className: 'build-card',
    header: () => [
      h(
        'span',
        { className: 'build-type-dot', style: { color: typeSty.color } },
        typeSty.icon,
      ),
      h('span', { className: 's-card-title' }, data.name || '未命名'),
      lv ? h('span', { className: 'build-level' }, lv) : null,
      h(
        'span',
        {
          className: 'build-status-tag',
          style: {
            color: statSty.color,
            background: statSty.bg,
            borderColor: statSty.color,
          },
        },
        data.status || '未知',
      ),
      h(
        'button',
        {
          className: 's-card-add',
          onClick: (e) => {
            e.stopPropagation();
            appendItemInput(data);
          },
        },
        '✚',
      ),
    ],
    children: () =>
      data.desc ? h('div', { className: 'build-desc' }, data.desc) : null,
  });
}

function BuildingTabContent({ buildings }) {
  const [filter, setFilter] = useState('*');
  const entries = Object.entries(buildings || {});
  const filtered =
    filter === '*'
      ? entries
      : entries.filter(([, v]) => {
          const t = (v.type || '').trim();
          if (filter === '其他') {
            const known = /居住|生产|仓储|防御|农业|医疗|研究|探索/;
            return !known.test(t);
          }
          return t.includes(filter) || t === filter;
        });

  const filterTabs = [
    { key: '*', label: '全部' },
    { key: '居住', label: '🏠 居住' },
    { key: '生产', label: '🔧 生产' },
    { key: '仓储', label: '📦 仓储' },
    { key: '防御', label: '🛡️ 防御' },
    { key: '农业', label: '🌾 农业' },
    { key: '医疗', label: '🏥 医疗' },
    { key: '研究', label: '🔬 研究' },
    { key: '其他', label: '… 其他' },
  ];

  if (entries.length === 0) {
    return h(
      'div',
      { className: 'build-empty' },
      h('div', { className: 'chara-empty-icon' }, '🏗️'),
      h('div', { className: 'chara-empty-text' }, '尚未建造任何设施'),
    );
  }

  return h(
    'div',
    { className: 'build-root' },
    h(
      'div',
      { className: 'build-filters' },
      filterTabs.map((f) =>
        h(
          'button',
          {
            key: f.key,
            className: `build-filter-btn${filter === f.key ? ' active' : ''}`,
            onClick: () => setFilter(f.key),
          },
          f.label,
        ),
      ),
    ),
    h(
      'div',
      { className: 'build-list' },
      filtered.map(([name, data]) => h(BuildingCard, { data, key: name })),
    ),
  );
}

// ============================================================
// Tab: 🎒 物品
// ============================================================

function getItemTypeStyle(type) {
  const t = (type || '').trim();
  const rules = [
    { match: /食物|水|罐头|粮食|食材/, icon: '🍖', color: 'var(--orange)' },
    { match: /医疗|药品|急救|药/, icon: '💊', color: 'var(--red)' },
    { match: /武器|弹药|刀|枪|棍/, icon: '🔫', color: 'var(--text2)' },
    { match: /工具|零件|材料/, icon: '🔧', color: 'var(--blue)' },
    { match: /衣物|护甲|背包|鞋/, icon: '👕', color: '#06b6d4' },
    { match: /书籍|日记|地图|文件|笔记/, icon: '📖', color: '#8b5cf6' },
  ];
  for (const r of rules) {
    if (r.match.test(t)) return { icon: r.icon, color: r.color };
  }
  return { icon: '📦', color: 'var(--text3)' };
}

function getItemStatusStyle(status) {
  const s = (status || '').trim();
  const rules = [
    {
      match: /剩|有|还够|足够|满|多|余/,
      color: 'var(--green)',
      bg: 'rgba(22,163,74,.12)',
    },
    {
      match: /半|一点|不多|少|缺|些许/,
      color: '#ca8a04',
      bg: 'rgba(202,138,4,.12)',
    },
    {
      match: /尽|没|空|即将|快|损|坏|锈|松/,
      color: 'var(--red)',
      bg: 'rgba(220,38,38,.12)',
    },
  ];
  for (const r of rules) {
    if (r.match.test(s)) return { color: r.color, bg: r.bg };
  }
  return { color: 'var(--text3)', bg: 'rgba(0,0,0,.04)' };
}

function ItemCard({ data }) {
  const typeSty = getItemTypeStyle(data.type);
  const statSty = data.status ? getItemStatusStyle(data.status) : null;

  return h(SExpand, {
    className: 'item-card',
    header: () => [
      h('span', { style: { color: typeSty.color } }, typeSty.icon),
      h('span', { className: 's-card-title' }, data.name || '未命名'),
      data.status
        ? h(
            'span',
            {
              className: 'item-status-tag',
              style: {
                color: statSty.color,
                background: statSty.bg,
                borderColor: statSty.color,
              },
            },
            data.status,
          )
        : null,
      h(
        'button',
        {
          className: 's-card-add',
          onClick: (e) => {
            e.stopPropagation();
            appendItemInput(data);
          },
        },
        '✚',
      ),
    ],
    children: () =>
      data.desc ? h('div', { className: 'build-desc' }, data.desc) : null,
  });
}

function ItemTabContent({ items }) {
  const entries = Object.entries(items || {});
  const filterTabs = [
    { key: '*', label: '全部' },
    { key: '食物', label: '🍖 食物' },
    { key: '医疗', label: '💊 医疗' },
    { key: '武器', label: '🔫 武器' },
    { key: '工具', label: '🔧 工具' },
    { key: '其他', label: '… 其他' },
  ];

  if (entries.length === 0) {
    return h(
      'div',
      { className: 'build-empty' },
      h('div', { className: 'chara-empty-icon' }, '🎒'),
      h('div', { className: 'chara-empty-text' }, '背包空空如也'),
    );
  }

  const [filter, setFilter] = useState('*');
  const filtered =
    filter === '*'
      ? entries
      : entries.filter(([, v]) => {
          const t = (v.type || '').trim();
          if (filter === '其他') {
            const known = /食物|医疗|武器|工具/;
            return !known.test(t);
          }
          return t.includes(filter) || t === filter;
        });

  return h(
    'div',
    { className: 'build-root' },
    h(
      'div',
      { className: 'build-filters' },
      filterTabs.map((f) =>
        h(
          'button',
          {
            key: f.key,
            className: `build-filter-btn${filter === f.key ? ' active' : ''}`,
            onClick: () => setFilter(f.key),
          },
          f.label,
        ),
      ),
    ),
    h(
      'div',
      { className: 'build-list' },
      filtered.map(([name, data]) => h(ItemCard, { data, key: name })),
    ),
  );
}

// ============================================================
// App
// ============================================================
function App() {
  const [variables] = useMessageData('variables');

  return SFloating({
    children: () =>
      h(STab, {
        layout: (header, content) =>
          h(
            'div',
            {
              className: 'sim-panel',
            },
            header,
            content,
          ),
        tabs: [
          {
            id: 'property',
            header: () => '🩺 个人状态',
            content: () =>
              h(PropertyTabContent, {
                user: get(variables, 'user', {}),
              }),
          },
          {
            id: 'charas',
            header: () => '👥 角色列表',
            content: () =>
              h(CharasTabContent, {
                charas: get(variables, 'charas', {}),
              }),
          },
          {
            id: 'buildings',
            header: () => '🏗️ 建筑',
            content: () =>
              h(BuildingTabContent, {
                buildings: get(variables, 'buildings', {}),
              }),
          },
          {
            id: 'items',
            header: () => '🎒 物品',
            content: () =>
              h(ItemTabContent, {
                items: get(variables, 'items', {}),
              }),
          },
        ],
      }),
    button: () => '🔮',
    className: 'sim-floating',
  });
}

renderComponent(App, 'sim-app');
