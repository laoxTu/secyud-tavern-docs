<variable_rules>

# 模拟经营

格式

```ts
// 所有属性60为正常人的数值
interface Property {
  str: number; // 力量
  dex: number; // 敏捷
  con: number; // 体质
  int: number; // 智力
  wis: number; // 感知
  cha: number; // 魅力
}

export interface Variable {
  // 主角信息
  user: {
    name: string; // 主角姓名
    desc: string; // 主角描述
    property: Property; // 主角属性
  };
  // 人物合集
  charas: Record<
    string,
    {
      name: string; // 人物姓名
      desc: string; // 人物描述
      relation: '友好' | '中立' | '敌对' | string; // 人物对主角的立场, 2-4字符
      status: '健康' | '危险' | '死亡' | string; // 人物状态, 2-4字符
      statusDesc: string; // 状态详细描述
      property: Property; // 人物属性
    }
  >;
  // 功能建筑合集
  buildings: Record<
    string,
    {
      name: string; // 建筑名称
      type: string; // 建筑类型，四字以内
      level: number; // 建筑等级
      status: string; // 建筑状态
      desc: string; // 建筑描述，主要是功能描述
    }
  >;
  // 物品合集
  items: Record<
    string,
    {
      name: string; // 物品名称
      type: string; // 物品类型，2-4字符
      status: string; // 物品状态，主要描述剩余数量，2-6字符
      desc: string; // 物品描述
    }
  >;
}
```

要求

- 开始时应当初始化`user`对象。
- 在新的对象出现时，将对象添加到相应的合集中。
  - 例如，人物张三即将登场，将张三添加到`charas`。
  - 新增对象时设置对象整体。
- 在已有对象出现时，需要更改已有对象的属性。
  - 例如，人物张三经过锻炼，体质增强，应当设置张三的体质。
  - 修改已有对象时只能逐个修改对象属性。未变化的属性不可修改。
- 所有合集的键必须是唯一标识符而不是名称，唯一标识符永远不变，只变更内容。
  - 例如，`charas`出现 `{"未知人物1": {...}}`当知晓他的名称为张三时，只更改里面的`name`，`{"未知人物1": {"name":"张三",...}}`
- 所有对象属性不可为空，需根据上下文填充或推测，六维可小范围随机。

建筑类型参考

```
/居住|房屋|宿舍|帐篷/
/生产|工坊|制造|熔炉|厨房/
/仓储|仓库|地窖/
/防御|哨塔|围墙|陷阱|堡垒/
/农业|菜园|种植|养殖|农场/
/医疗|诊所|药房/
/研究|实验室|图书馆/
/探索|通讯|侦察|无线电/
```

建筑状态参考

```
/运作中|正常|健康/
/建设中|建造中|施工/
/损坏|破损|坍塌/
/闲置|空闲|无人|休眠/
```

物品类型参考

```
/食物|水|罐头|粮食|食材/
/医疗|药品|急救|药/
/武器|弹药|刀|枪|棍/
/工具|零件|材料/
/衣物|护甲|背包|鞋/
/书籍|日记|地图|文件|笔记/
```

</variable_rules>
