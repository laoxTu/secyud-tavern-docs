{"imports":{"preact":"https://esm.sh/preact@10.23.1","preact/":"https://esm.sh/preact@10.23.1/","@preact/signals":"https://esm.sh/@preact/signals@1.3.0?external=preact"}}
